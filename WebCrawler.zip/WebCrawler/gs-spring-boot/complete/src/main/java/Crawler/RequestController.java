package Crawler;

import java.net.URI;

/**
 * 
 * @author araman
 *
 */

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class RequestController {
    @RequestMapping("/getInfo")
    public RequestInfo get(@RequestParam(value="url") String url) {
       return Utils.getInfo(url);  
    }
    
    @RequestMapping("/setInfo")
    public void set(@RequestParam(value="url") String url, @RequestParam(value="maxDepth", defaultValue= "2") String maxDepth) {
    	try {
    		URI uri = URI.create(url);
			Utils.crawlPages(uri, 0, Integer.parseInt(maxDepth));
		} catch (Exception e) {
			e.printStackTrace();
		}
    }
}
