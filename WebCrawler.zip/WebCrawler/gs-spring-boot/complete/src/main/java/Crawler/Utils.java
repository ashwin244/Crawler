package Crawler;

import java.net.URI;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.util.Calendar;
import java.util.Date;
import java.util.Set;

import org.eclipse.jetty.client.HttpClient;
import org.eclipse.jetty.client.api.Response;
import org.eclipse.jetty.client.api.Result;
import org.eclipse.jetty.util.ConcurrentHashSet;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.rocksdb.RocksDB;
import org.rocksdb.RocksDBException;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

/**
 * 
 * @author araman
 *
 */
public class Utils {
	static HttpClient client = new HttpClient();

	private static Set<String> parsedLinks = new ConcurrentHashSet<>();

	public static void init() throws Exception {
		if (!client.isStarted()) {
			client.start();
		}
	}

	/*
	 * Jetty Async call to crawl pages and store them in rocksDB on Complete
	 * event, as soon as the content is received recursively crawl pages until
	 * depth is less that maxDepth or there are no more links to crawl
	 */
	public static void crawlPages(final URI uri, final int depth, final int maxDepth) throws Exception {
		init();
		if (!parsedLinks.contains(uri.toString()) && depth < maxDepth) {
			client.newRequest(uri).send(new Response.Listener.Adapter() {
				@Override
				public void onContent(Response response, ByteBuffer buffer) {
					String s = new String(buffer.array(), Charset.forName("UTF-8"));
					parsedLinks.add(uri.toString());
					process(s, uri.getHost(), depth, maxDepth);
				}

				@Override
				public void onComplete(Result result) {
					RequestInfo info = new RequestInfo(uri.toString(), result.getResponse().getStatus(),
							Calendar.getInstance().getTime());
					RocksDB db = RocksDataBase.getConnection();
					Gson gson = new GsonBuilder().create();
					try {
						db.put(uri.toString().getBytes(), gson.toJson(info).getBytes());
					} catch (RocksDBException e) {
						System.err.println("Invalid entry to the database");
					}
				}
			});
		}
		//Uncomment if we need to close data base connection after pages crawled : RocksDataBase.closeConnection();
	}

	/*
	 * fetch the url information from the database
	 */
	public static RequestInfo getInfo(String url) {
		RocksDB db = RocksDataBase.getConnection();
		byte[] bytes = null;
		try {
			bytes = db.get(url.getBytes());
			
			if(bytes == null || bytes.length == 0) {
				return new RequestInfo("URL doesn't exist", 0, new Date(0));
			}
			
		} catch (RocksDBException e) {
			System.err.println("Invalid query");
		}
		Gson gson = new GsonBuilder().create();
		return gson.fromJson(new String(bytes), RequestInfo.class);

	}

	/*
	 *  Process the individual page content to find the links 
	 */
	private static void process(String s, String host, int depth, int maxDepth) {
		Document doc = Jsoup.parse(s);
		Elements links = doc.select("a");

		for (Element page : links) {
			String url = page.attr("href");
			try {

				URI uri = URI.create(url);
				depth = host.equals(uri.getHost()) ? depth++ : depth;

				crawlPages(uri, depth, maxDepth);
			} catch (IllegalArgumentException e) {
				System.err.println("Invalid URL : " + url);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
}
