package Crawler;

import java.util.Date;

/**
 * 
 * Information requested by rest api
 * @author araman
 *
 */
public class RequestInfo {
    private String url;
    private int statusCode;
    private Date timeStamp;
    
    
	public RequestInfo(String url, int statusCode, Date timeStamp) {
		super();
		this.url = url;
		this.statusCode = statusCode;
		this.timeStamp = timeStamp;
	}
	
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public int getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}
	public Date getTimeStamp() {
		return timeStamp;
	}
	public void setTimeStamp(Date timeStamp) {
		this.timeStamp = timeStamp;
	}
    
    
}
