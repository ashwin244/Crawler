package Crawler;

import org.rocksdb.RocksDB;
import org.rocksdb.RocksDBException;


/**
 * 
 * @author araman
 *
 */
public class RocksDataBase {
	public static RocksDB db = null;
	
	//initialize rocksDB
	public static void init() {
		RocksDB.loadLibrary();
	}
	
	//fetch DB connection
	public static RocksDB getConnection() {
		try {
		    db = db == null ? RocksDB.open("C:/rocksDB") : db;  
		  } catch (RocksDBException e) {
			  e.printStackTrace();
		  }
		
		return db; 
	}
	
	//close DB connection
	public static void closeConnection() {
		if (db != null) db.close();
	}
	
	
	
}
