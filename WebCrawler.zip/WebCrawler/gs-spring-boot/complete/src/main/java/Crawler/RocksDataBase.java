package Crawler;

import org.rocksdb.Options;
import org.rocksdb.RocksDB;
import org.rocksdb.RocksDBException;


/**
 * 
 * @author araman
 *
 */
public class RocksDataBase {
	public static RocksDB db = null;
	
	public static void init() {
		RocksDB.loadLibrary();
	}
	
	public static RocksDB getConnection() {
		try {
		    db = db == null ? RocksDB.open("C:/rocksDB") : db;  
		  } catch (RocksDBException e) {
			  e.printStackTrace();
		  }
		
		return db; 
	}
	
	public static void closeConnection() {
		if (db != null) db.close();
	}
	
	
	
}
